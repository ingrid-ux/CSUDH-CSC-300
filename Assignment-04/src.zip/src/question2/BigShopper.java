package question2;

import java.util.Random;

public class BigShopper extends Shopper {

    private Random randy;
    public static int bigShopperCounter = 0;
    public static final int TIMEWITHCHECKER = 2;
    private String bigShopperID;

    private int startTime;
    private int timeShopping;
    private int shoppingTimeRemaining;
    private int timeIntoCheckoutLine;
    private int timeOutOfCheckoutLine;
    private int endTime;
    private int totalTimeCheckingOut;
    private int totalTimeInStore;


    public BigShopper(int startTime){
        super("BigShopper");
        randy = new Random(bigShopperCounter);
        setBigShopperID();
        setStartTime(startTime);
        setTimeShopping();
        setShoppingTimeRemaining(timeShopping);

    }

    public String getBigShopperID() {
        return bigShopperID;
    }

    // ** startTime *
    public int getStartTime() {
        return startTime;
    }

    public void setStartTime(int startTime) {
        this.startTime = startTime;
    }

    // ** timeShopping
    public int getTimeShopping() {
        return timeShopping;
    }

    // ** shoppingTimeRemaining *
    @Override
    public void setShoppingTimeRemaining(int timeRemaining) {
        this.shoppingTimeRemaining = timeRemaining;
    }

    @Override
    public int getShoppingTimeRemaining() {
        return shoppingTimeRemaining;
    }

    // ** timeIntoCheckoutLine *
    @Override
    public void setTimeIntoCheckoutLine(int timeIntoCheckoutLine) {
        this.timeIntoCheckoutLine = timeIntoCheckoutLine;
    }

    public int getTimeIntoCheckoutLine() {
        return timeIntoCheckoutLine;
    }

    // ** timeOutOfCheckoutLine
    public void setTimeOutOfCheckoutLine(int time) {
        this.timeOutOfCheckoutLine = time;
        calculateFinalDurations();
    }

    public int getTimeOutOfCheckoutLine() {
        return timeOutOfCheckoutLine;
    }

    // ** endTime
    public int getEndTime() {
        return endTime;
    }

    // ** totalTimeCheckingOut
    @Override
    public int getTotalTimeCheckingOut() {
        return totalTimeCheckingOut;
    }

    // ** totalTimeInStore
    public int getTotalTimeInStore() {
        return totalTimeInStore;
    }


    public void setBigShopperID() {
        bigShopperCounter++;
        bigShopperID = getShopperType() + bigShopperCounter;
    }

    public void setTimeShopping() {
        timeShopping = randy.nextInt(11) + 5;
    }

    public void calculateFinalDurations(){
        endTime = timeOutOfCheckoutLine + TIMEWITHCHECKER;
        totalTimeCheckingOut = Math.abs(endTime - timeIntoCheckoutLine);
        totalTimeInStore = Math.abs(endTime - startTime);
    }

    @Override
    public String toString() {
        return String.format(
                "%-15s %-15d %-15d %-15d %-15d %-15d",
                bigShopperID,
                startTime,
                endTime,
                timeShopping,
                totalTimeCheckingOut,
                totalTimeInStore
        );
    }
}
